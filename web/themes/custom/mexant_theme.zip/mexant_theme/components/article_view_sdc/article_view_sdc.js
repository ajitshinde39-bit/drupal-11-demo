(function(Drupal) {

  Drupal.behaviors.articleViewSdc = {
    attach(context) {
      console.log('@todo Replace me with the real JS behavior.');
    },
  };

})(Drupal);
